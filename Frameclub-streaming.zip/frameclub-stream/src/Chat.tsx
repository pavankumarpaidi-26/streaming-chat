import React, { useState, useRef, useEffect, useLayoutEffect } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";
type Part = { kind: "text" | "done" | "error"; text: string };
type Line = {
  role: "user" | "assistant";
  content: string;
  state?: "stopped" | "error";
};
function Chat() {
  const [lines, set] = useState<Line[]>([]),
    [draft, D] = useState(""),
    [busy, B] = useState(false),
    [mode, M] = useState("Checking connection"),
    [away, A] = useState(false);
  const controller = useRef<AbortController | null>(null),
    pane = useRef<HTMLDivElement>(null),
    pin = useRef(true),
    input = useRef<HTMLTextAreaElement>(null);
  useEffect(() => {
    fetch("/api/mode")
      .then((r) => r.json())
      .then((x) => M(x.live ? "Claude live" : "Local demo · no Claude key"))
      .catch(() => M("Server unavailable"));
    return () => controller.current?.abort();
  }, []);
  useLayoutEffect(() => {
    if (pin.current && pane.current)
      pane.current.scrollTop = pane.current.scrollHeight;
  }, [lines]);
  function latest() {
    pin.current = true;
    A(false);
    if (pane.current) pane.current.scrollTop = pane.current.scrollHeight;
  }
  async function send(value: string) {
    const text = value.trim();
    if (!text || controller.current) return;
    const user: Line = { role: "user", content: text };
    const next = [...lines, user];
    const ac = new AbortController();
    controller.current = ac;
    set([...next, { role: "assistant", content: "" }]);
    B(true);
    D("");
    latest();
    const patch = (fn: (l: Line) => Line) =>
      set((prev) => [...prev.slice(0, -1), fn(prev[prev.length - 1])]);
    try {
      const messages = next
        .slice(-31)
        .map((l) => ({
          role: l.role,
          content:
            l.content ||
            (l.state === "stopped"
              ? "[Reply stopped before text]"
              : "[Reply unavailable]"),
        }));
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages }),
        signal: ac.signal,
      });
      if (!r.ok || !r.body) throw Error();
      const reader = r.body.pipeThrough(new TextDecoderStream()).getReader();
      let buf = "",
        done = false;
      while (!done) {
        const chunk = await reader.read();
        if (chunk.done) throw Error();
        buf += chunk.value;
        let end;
        while ((end = buf.indexOf("\n\n")) >= 0) {
          const frame = buf.slice(0, end);
          buf = buf.slice(end + 2);
          if (!frame.startsWith("data: ")) continue;
          const event: Part = JSON.parse(frame.slice(6));
          if (event.kind === "text")
            patch((l) => ({ ...l, content: l.content + event.text }));
          else if (event.kind === "done") done = true;
          else throw Error();
        }
      }
    } catch {
      patch((l) => ({ ...l, state: ac.signal.aborted ? "stopped" : "error" }));
    } finally {
      controller.current = null;
      B(false);
      input.current?.focus();
    }
  }
  return (
    <main>
      <header>
        <b>◈ Frameclub</b>
        <span>CURATOR DESK / 01</span>
      </header>
      <section className="title">
        <small>FIELD NOTES &nbsp; / &nbsp; FILM DISCOVERY</small>
        <h1>
          The screening room<span>.</span>
        </h1>
        <p>A conversation to find your next film.</p>
        <em>{mode}</em>
      </section>
      <div
        className="pane"
        ref={pane}
        aria-label="Conversation"
        role="region"
        tabIndex={0}
        onWheel={(e) => {
          if (e.deltaY < 0) {
            pin.current = false;
            A(true);
          }
        }}
        onScroll={(e) => {
          const el = e.currentTarget;
          pin.current = el.scrollHeight - el.clientHeight - el.scrollTop < 3;
          A(!pin.current);
        }}
      >
        {!lines.length ? (
          <article className="empty">
            <small>START A CONVERSATION</small>
            <h2>What fits tonight?</h2>
            <p>Tell the curator your mood, or start with a suggestion.</p>
            {[
              "A whimsical caper",
              "Something about space",
              "The shortest film",
            ].map((s) => (
              <button key={s} onClick={() => send(s)}>
                {s} ↗
              </button>
            ))}
          </article>
        ) : (
          lines.map((l, i) => (
            <article key={i} className={l.role}>
              <small>{l.role === "user" ? "YOU" : "FRAMECLUB CURATOR"}</small>
              <p>{l.content || (!l.state ? "Thinking…" : "")}</p>
              {l.state && (
                <em>
                  {l.state === "stopped"
                    ? "Stopped"
                    : "Connection interrupted. Try another message."}
                </em>
              )}
            </article>
          ))
        )}
      </div>
      {away && (
        <button className="jump" onClick={latest}>
          Jump to latest ↓
        </button>
      )}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(draft);
        }}
      >
        <label htmlFor="message">Your message</label>
        <div>
          <textarea
            id="message"
            ref={input}
            rows={2}
            maxLength={1200}
            value={draft}
            placeholder="I’m in the mood for…"
            onChange={(e) => D(e.target.value)}
            onKeyDown={(e) => {
              if (
                e.key === "Enter" &&
                !e.shiftKey &&
                !e.nativeEvent.isComposing
              ) {
                e.preventDefault();
                send(draft);
              }
            }}
          />
          {busy ? (
            <button type="button" onClick={() => controller.current?.abort()}>
              ■ Stop
            </button>
          ) : (
            <button disabled={!draft.trim()}>Send ↗</button>
          )}
        </div>
      </form>
      <span className="sr" role="status">
        {busy ? "Receiving reply" : lines.length ? "Reply finished" : "Ready"}
      </span>
    </main>
  );
}
createRoot(document.getElementById("root")!).render(<Chat />);

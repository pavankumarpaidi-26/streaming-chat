const puppeteer = require("puppeteer-core"),
  assert = require("node:assert/strict");
(async () => {
  const b = await puppeteer.launch({
    executablePath: process.env.CHROME_PATH,
    args: ["--no-sandbox"],
  });
  try {
    const p = await b.newPage();
    await p.setViewport({ width: 360, height: 640 });
    await p.goto("http://localhost:4280");
    await p.click(".empty button");
    await p.waitForFunction(
      () => document.querySelector(".assistant p")?.textContent === "Thinking…",
    );
    await p.waitForFunction(() =>
      document.querySelector(".assistant p")?.textContent.includes("Budapest"),
    );
    await p.click("form button");
    await p.waitForSelector(".assistant em");
    const partial = await p.$eval(".assistant p", (e) => e.textContent);
    assert.ok(partial.includes("Budapest"));
    await p.type("textarea", "The shortest film");
    await p.keyboard.press("Enter");
    await p.waitForFunction(
      () =>
        document.querySelectorAll(".assistant").length === 2 &&
        !document.querySelector("form button[type=button]"),
    );
    assert.equal(await p.$eval(".assistant p", (e) => e.textContent), partial);
    assert.ok(
      await p.$eval(".assistant:last-child", (e) =>
        e.textContent.includes("99 minutes"),
      ),
    );
    assert.ok(
      await p.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    );
    console.log(
      "PASS at 360px: thinking → partial text → Stop → preserved partial → second completed reply; no horizontal overflow.",
    );
  } finally {
    await b.close();
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});

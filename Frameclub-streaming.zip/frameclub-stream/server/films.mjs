export const films = [
  [
    "arrival",
    "Arrival",
    "Denis Villeneuve",
    2016,
    "Sci-fi",
    116,
    "A linguist searches for common ground with visitors whose language changes how she understands time.",
  ],
  [
    "grand",
    "The Grand Budapest Hotel",
    "Wes Anderson",
    2014,
    "Comedy",
    99,
    "A young lobby boy and a devoted concierge become tangled in an inheritance dispute in a fading European resort.",
  ],
  [
    "moon",
    "Moonlight",
    "Barry Jenkins",
    2016,
    "Drama",
    111,
    "Three chapters trace a young man’s search for tenderness and identity in Miami.",
  ],
  [
    "spirited",
    "Spirited Away",
    "Hayao Miyazaki",
    2001,
    "Animation",
    125,
    "A girl takes a job in a bathhouse for spirits to find a way home for her family.",
  ],
  [
    "interstellar",
    "Interstellar",
    "Christopher Nolan",
    2014,
    "Sci-fi",
    169,
    "Explorers leave a struggling Earth to investigate distant worlds on the other side of a wormhole.",
  ],
  [
    "lunch",
    "The Lunchbox",
    "Ritesh Batra",
    2013,
    "Drama",
    104,
    "A mistaken lunch delivery opens a correspondence between two lonely people in Mumbai.",
  ],
].map(([id, title, director, year, genre, minutes, summary]) => ({
  id,
  title,
  director,
  year,
  genre,
  minutes,
  summary,
}));
export function select(list, q, genre) {
  return list.filter(
    (f) =>
      (genre === "All genres" || f.genre === genre) &&
      `${f.title} ${f.director}`.toLowerCase().includes(q.trim().toLowerCase()),
  );
}
export function restore(raw) {
  try {
    const ids = JSON.parse(raw);
    return Array.isArray(ids)
      ? [...new Set(ids.filter((id) => films.some((f) => f.id === id)))]
      : [];
  } catch {
    return [];
  }
}

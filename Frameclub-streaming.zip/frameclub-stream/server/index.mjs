import express from "express";
import { chat, live } from "./chat.mjs";
const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "48kb" }));
app.get("/api/mode", (_, res) => res.json({ live }));
app.post("/api/chat", chat);
app.use(express.static("dist"));
app.listen(process.env.PORT || 4280, "0.0.0.0");

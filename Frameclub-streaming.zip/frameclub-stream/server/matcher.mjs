// Supervised multinomial Naive Bayes; one class per catalog film.
const examples = {
  arrival: [
    "thoughtful quiet science fiction about language",
    "aliens and communication through time",
    "cerebral first contact mystery",
    "reflective alien encounter and grief",
  ],
  grand: [
    "playful colorful comedy and mischief",
    "witty eccentric hotel adventure",
    "whimsical funny madcap caper",
    "stylish amusing farce",
  ],
  moon: [
    "intimate emotional coming of age",
    "identity and belonging growing up",
    "tender queer drama about childhood",
    "personal reflective journey through adolescence",
  ],
  spirited: [
    "magical animated fantasy world",
    "imaginative adventure with spirits",
    "enchanted family adventure and wonder",
    "dreamlike animation and folklore",
  ],
  interstellar: [
    "epic space adventure among stars",
    "cosmic voyage and exploration",
    "ambitious science fiction about astronauts",
    "space travel and survival epic",
  ],
  lunch: [
    "gentle romance and food",
    "quiet connection through letters",
    "warm everyday love and cooking",
    "gentle bittersweet romance in Mumbai",
  ],
};
const stop = new Set(
  "a an and the i want something to with for of in about tonight some me".split(
    " ",
  ),
);
const tokens = (s) =>
  (s.toLowerCase().match(/[a-z]+/g) || []).filter((t) => !stop.has(t));
const vocab = new Set(),
  classes = Object.entries(examples).map(([id, rows]) => {
    const words = rows.flatMap(tokens),
      counts = new Map();
    for (const w of words) {
      vocab.add(w);
      counts.set(w, (counts.get(w) || 0) + 1);
    }
    return { id, counts, n: words.length };
  });
export function match(text) {
  if (typeof text !== "string" || text.length > 240) return { kind: "invalid" };
  const terms = [...new Set(tokens(text))].filter((w) => vocab.has(w));
  if (!terms.length) return { kind: "unknown" };
  const ranked = classes
    .map(({ id, counts, n }) => ({
      id,
      terms: terms.filter((w) => counts.has(w)),
      score: terms.reduce(
        (s, w) => s + Math.log(((counts.get(w) || 0) + 1) / (n + vocab.size)),
        0,
      ),
    }))
    .sort((a, b) => b.score - a.score);
  if (ranked[0].score - ranked[1].score < 0.15) return { kind: "unknown" };
  return { kind: "match", id: ranked[0].id, terms: ranked[0].terms };
}

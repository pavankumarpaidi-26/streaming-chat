import Anthropic from "@anthropic-ai/sdk";
import { setTimeout as delay } from "node:timers/promises";
import { config } from "./config.mjs";
import { films } from "./films.mjs";
import { match } from "./matcher.mjs";
export const live = Boolean(process.env.ANTHROPIC_API_KEY);
let active = 0;
const calls = [];
function local(messages) {
  const q = messages.at(-1).content.toLowerCase(),
    prior =
      messages.filter((m) => m.role === "assistant").at(-1)?.content || "";
  const prev = films.find((f) => prior.includes(f.title)),
    pick = match(q);
  let film =
    films.find((f) => q.includes(f.title.toLowerCase())) ||
    films.find((f) => f.id === pick.id);
  if (/short|quick|less time/.test(q))
    film = [...films].sort((a, b) => a.minutes - b.minutes)[0];
  else if (!film && /another|different|instead/.test(q))
    film = films.find((f) => f.id !== prev?.id);
  else if (!film && prev && /why|director|long|more|about/.test(q)) film = prev;
  if (!film)
    return "What kind of evening do you have in mind? Try a whimsical caper, quiet romance, or space exploration. I can also find the shortest film in the programme.";
  return `${film.title} (${film.year}) is my pick. ${film.summary}\n\nDirected by ${film.director}, it runs ${film.minutes} minutes. ${film === prev ? "Would you like a different option?" : "Want something shorter, or another recommendation?"}`;
}
export async function chat(req, res) {
  const m = req.body?.messages;
  if (
    !Array.isArray(m) ||
    !m.length ||
    m.length > 32 ||
    m.at(-1)?.role !== "user" ||
    m.some(
      (x, i) =>
        !x ||
        x.role !== (i % 2 ? "assistant" : "user") ||
        typeof x.content !== "string" ||
        !x.content.trim() ||
        x.content.length > 4000,
    )
  )
    return res.status(400).json({ error: "Invalid conversation" });
  const now = Date.now();
  while (calls.length && calls[0] < now - 60000) calls.shift();
  if (active >= 4 || calls.length >= 24) return res.status(429).end();
  active++;
  calls.push(now);
  const ac = new AbortController(),
    timer = setTimeout(() => ac.abort(), 75000);
  res.on("close", () => ac.abort());
  res
    .set({
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    })
    .flushHeaders();
  const send = (kind, text = "") => {
    if (!res.destroyed)
      res.write(`data: ${JSON.stringify({ kind, text })}\n\n`);
  };
  try {
    if (live) {
      const client = new Anthropic();
      const stream = await client.messages.create(
        {
          ...config,
          messages: m.map(({ role, content }) => ({ role, content })),
          stream: true,
        },
        { signal: ac.signal },
      );
      for await (const event of stream)
        if (
          event.type === "content_block_delta" &&
          event.delta.type === "text_delta"
        )
          send("text", event.delta.text);
    } else {
      await delay(400, null, { signal: ac.signal });
      for (const word of local(m).match(/\S+\s*/g) || []) {
        await delay(65, null, { signal: ac.signal });
        send("text", word);
      }
    }
    send("done");
  } catch {
    send("error", "Stream interrupted. You can send another message.");
  } finally {
    active--;
    clearTimeout(timer);
    res.end();
  }
}

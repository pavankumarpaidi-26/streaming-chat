# Frameclub — streaming curator desk
Node 20+, React, TypeScript, Express and the official Anthropic SDK. From this directory run `npm ci`, `npm run build`, `npm start`. Open http://localhost:4280. PowerShell: use `npm.cmd` instead of `npm`.

## Modes and deployment
Without credentials the UI explicitly labels a local six-film demo. It can classify a mood, reuse the prior recommendation, suggest another film, or choose the shortest. Demo chunks are simulated, not Claude output. Set `ANTHROPIC_API_KEY` as a **server environment secret** and restart for real Claude streaming. `ANTHROPIC_MODEL` can override the model ID in server/config.mjs. Do not put keys in VITE_ variables or the repository. Never paste your key into the chat UI. Provider errors are surfaced, not silently replaced with demo replies.

Deploy to a Node web service, not a static-only host. Build: `npm ci && npm run build`. Start: `npm start`. The server honors `PORT`. Disable proxy buffering for `/api/chat`. Configure a billing budget; the in-memory concurrency and request limits protect a single instance only. For a durable public submission use an authenticated or quota-limited deployment and supply its public URL and repository file permalinks.

## Review map
- `server/chat.mjs`: validates role order and text bounds, streams typed SSE text/done/error frames, aborts the provider on client disconnect, and caps request lifetime.
- `server/config.mjs`: instructions, catalogue grounding, model and output budget.
- `src/Chat.tsx`: POST + incremental UTF-8 decoding; thinking state replaced by the first text part; AbortController retains partial replies; plain text rather than fragile partial Markdown. Conversation stays in memory; the latest 31 messages provide bounded context. Refresh starts over.
- `smoke.cjs`: start in demo mode, set CHROME_PATH to Chrome, run `node smoke.cjs`. Exercises the stop-then-send flow at 360px. For a manual scroll check, send several turns, scroll up during a reply, and use Jump to latest to resume following it. No live provider result was verified without credentials.
